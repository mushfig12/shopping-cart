package com.perscholas.shoppingCart;



public class CartSystem extends TheSystem {
	 CartSystem  () {
	    }

	    @Override
	    public void display() {
			
		
				try {
					final double TAX = 0.05;
					
					double subTotal = 0.0;
					double preTaxTotal = 0.0;
					System.out.println("Cart");
System.out.printf("%-20s%-20s%-10s%-10s%-10s\n","Name", "Description", "Price", "Quantity","Sub Total");					


						for(Item item : getItemCollection().values()) {
							subTotal= item.getItemPrice()*item.getQuantity();
System.out.printf("%-20s%-20s%-10.2f%-10d%-10.2f\n" , item.getItemName(), item.getItemDesc(), item.getItemPrice(),item.getQuantity(),subTotal);
preTaxTotal += subTotal;

						}
						System.out.println();

							System.out.printf("%-20s%-20.2f\n", "Pre-Tax Total", preTaxTotal);	
							System.out.printf("%-20s%-20.2f\n", "Tax", TAX*preTaxTotal);
							System.out.printf("%-20s%-20.2f\n", "Total", preTaxTotal+(TAX*preTaxTotal));
							System.out.println();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			
		}

}
