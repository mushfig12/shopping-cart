package com.perscholas.shoppingCart;

import java.io.File;

import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Scanner;



 
public abstract class TheSystem {
	HashMap<String, Item> itemCollection;
	Item item;

public HashMap<String, Item> getItemCollection() {
	// Your code here
	return itemCollection;
	}

public void setItemCollection(HashMap<String, Item> itemCollection) {
	this.itemCollection = itemCollection;
}


	TheSystem() {
		// Your code here
		itemCollection = new HashMap<String, Item>();
		if (getClass().getSimpleName().equals("AppSystem")) {
			try {
				File file = new File("Sample.txt");
				Scanner scanner = new Scanner(file);
				while (scanner.hasNextLine()) {
					String[] itemInfo = scanner.nextLine().split("  ");
					 item = new Item();
					item.setItemName(itemInfo[0]);
					item.setItemDesc(itemInfo[1]);
					item.setItemPrice(Double.valueOf(itemInfo[2]));
					item.setAvailableQuantity(Integer.valueOf(itemInfo[3]));
					itemCollection.put(item.getItemName(), item);
					
				}
				scanner.close();

			} catch (FileNotFoundException ex) {
				ex.printStackTrace();

			}
		}

	}

	
	public Boolean checkAvailability(Item item) {
		// Your code here
		if(item==null) {return false;}
		if  ( item.getQuantity() > item.getAvailableQuantity()) {
			System.out.println("System is unable to add [" + item.getItemName() + "] to the card. System only has ["
					+ item.getAvailableQuantity() + "] [" + item.getItemName() + "]s");
			return false;
		} else
			return true;
	}
	


	public Boolean add(Item item) {
		if(	itemCollection.containsKey(item.getItemName())) {
			item.setQuantity(item.getQuantity()+1);
			return true;
		}else if (!itemCollection.containsKey(item.getItemName())) {
			itemCollection.put(item.getItemName(), item);
		return true;}
		
		else return false;
	}


	
	public Item remove(String itemName) {
		// Your code here
				if (itemCollection.containsKey(itemName)) {
					
					return itemCollection.remove(itemName);			
				}else
				return null;	
	}

	public abstract void display();

	

}
