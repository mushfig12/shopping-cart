package com.perscholas.shoppingCart;

import java.util.HashMap;

public class AppSystem extends TheSystem{
	
	  AppSystem() {
	    }
 
	 	@Override
	    public void display()  {
	 	

			try {
				System.out.println("AppSystem Inventory");
System.out.printf("%-20s%-20s%-10s%-10s\n","Name", "Description", "Price", "Available Quantity");				


			
					for(Item item : getItemCollection().values()){
						 
System.out.printf("%-20s%-20s%-10.2f%-10d\n" , item.getItemName(), item.getItemDesc(), item.getItemPrice()
						,item.getAvailableQuantity());

					}
					System.out.println();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
				
			
		}
	    	
	    

	    	
	    @Override  
	    public Boolean add(Item item) {
	        // Your code here
	    	if (item == null) {
				return false;
	    	} else if (getItemCollection().containsKey(item.getItemName())) {
				System.out.println(item.getItemName() + " is already in the App System");
				return false;
			} else if (!getItemCollection().containsKey(item.getItemName())) {
				getItemCollection().put(item.getItemName(), item);
				return true;
			} 
			return false;
	    }
	    
	    public Item reduceAvailableQuantity(String item_name) {
	        // Your code here
	    	Item item = getItemCollection().get(item_name);
	    	if (getItemCollection().containsKey(item_name)) {
	    	item.setAvailableQuantity(getItemCollection().get(item_name).getAvailableQuantity() - 1);
	    	if(item.getAvailableQuantity()==0) {
	    	remove(item_name);
	    	}
			return item;				
			}
			return null;	
	    }

	  
}
